# Spotify 廣告靜音（Android）

偵測到 Spotify 廣告時自動將媒體音量靜音，廣告結束後恢復。
事件驅動，無輪詢；Spotify 關閉時監聽即卸載。

## 打包成 APK
**方法 A：Android Studio**
1. 用 Android Studio 開啟本資料夾，等 Gradle 同步完成。
2. Build > Build Bundle(s) / APK(s) > Build APK(s)。
3. APK 在 `app/build/outputs/apk/debug/app-debug.apk`，傳到手機安裝。

**方法 B：GitHub Actions（不需電腦環境）**
1. 把本專案推到你的 GitHub repo（main 分支）。
2. 到 Actions 執行「Build APK」，完成後下載 artifact。

## 使用
安裝後開啟 App，點「開啟通知存取權設定」，授權「Spotify 廣告靜音」。
之後不需再開本 App。
