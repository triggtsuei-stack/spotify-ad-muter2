package com.example.spotifyadmuter

import android.content.ComponentName
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.service.notification.NotificationListenerService

/**
 * 事件驅動的 Spotify 廣告靜音服務：
 * - 只有在系統回報 Spotify 的媒體工作階段出現時才掛上監聽（Spotify 開啟）
 * - Spotify 關閉、工作階段消失時立即卸載監聽並恢復聲音
 * - 全程沒有輪詢、沒有計時器，幾乎不耗電
 */
class AdMuteService : NotificationListenerService() {

    private lateinit var sessionManager: MediaSessionManager
    private lateinit var audio: AudioManager
    private lateinit var component: ComponentName

    private var controller: MediaController? = null
    private var weMuted = false

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { handleSessions(it) }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = evaluate(metadata)
        override fun onPlaybackStateChanged(state: android.media.session.PlaybackState?) =
            evaluate(controller?.metadata)
        override fun onSessionDestroyed() = detach()
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        sessionManager = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        component = ComponentName(this, AdMuteService::class.java)
        try {
            sessionManager.addOnActiveSessionsChangedListener(sessionsListener, component)
            handleSessions(sessionManager.getActiveSessions(component))
        } catch (_: SecurityException) {
            // 尚未取得「通知存取權」
        }
    }

    override fun onListenerDisconnected() {
        cleanup()
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        if (::sessionManager.isInitialized) {
            try {
                sessionManager.removeOnActiveSessionsChangedListener(sessionsListener)
            } catch (_: Exception) {
            }
        }
        detach()
    }

    private fun handleSessions(list: List<MediaController>?) {
        val spotify = list?.firstOrNull { it.packageName == SPOTIFY_PACKAGE }
        when {
            spotify == null -> detach()
            controller?.sessionToken == spotify.sessionToken -> Unit
            else -> attach(spotify)
        }
    }

    private fun attach(c: MediaController) {
        controller?.unregisterCallback(callback)
        controller = c
        c.registerCallback(callback)
        evaluate(c.metadata)
    }

    private fun detach() {
        controller?.unregisterCallback(callback)
        controller = null
        setMuted(false)
    }

    private fun evaluate(metadata: MediaMetadata?) {
        setMuted(isAd(metadata))
    }

    private fun isAd(m: MediaMetadata?): Boolean {
        if (m == null) return false
        val id = m.getString(MediaMetadata.METADATA_KEY_MEDIA_ID).orEmpty()
        val title = m.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty().trim().lowercase()
        val adFlag = try {
            m.getLong("android.media.metadata.ADVERTISEMENT") > 0
        } catch (_: Exception) {
            false
        }
        return id.startsWith("spotify:ad") || id.contains(":ad:") || adFlag || title in AD_TITLES
    }

    /** 只還原「我們自己靜音」的狀態，不會動到使用者自己設定的靜音。 */
    private fun setMuted(mute: Boolean) {
        if (!::audio.isInitialized) return
        if (mute && !weMuted) {
            if (!audio.isStreamMute(AudioManager.STREAM_MUSIC)) {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                weMuted = true
            }
        } else if (!mute && weMuted) {
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            weMuted = false
        }
    }

    companion object {
        private const val SPOTIFY_PACKAGE = "com.spotify.music"
        private val AD_TITLES = setOf("advertisement", "廣告", "广告", "spotify")
    }
}
