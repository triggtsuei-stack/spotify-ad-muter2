package com.example.spotifyadmuter

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Spotify 廣告靜音"
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
        })

        status = TextView(this).apply {
            textSize = 18f
            setPadding(0, pad, 0, pad)
        }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "開啟通知存取權設定"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        })

        root.addView(TextView(this).apply {
            textSize = 14f
            setPadding(0, pad, 0, 0)
            text = "使用方式：\n" +
                "1. 在設定中找到「Spotify 廣告靜音」並開啟。\n" +
                "2. 之後不用再開本 App。開啟 Spotify 時它自動開始偵測，" +
                "關閉 Spotify 時自動停止並恢復聲音。\n" +
                "3. 偵測到廣告時會將媒體音量靜音，廣告結束後自動恢復。\n\n" +
                "建議：到系統的電池設定，將本 App 設為「不受限制」，避免被系統回收。"
        })

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val enabled = Settings.Secure
            .getString(contentResolver, "enabled_notification_listeners")
            .orEmpty()
            .contains(packageName)
        status.text = if (enabled) "狀態：已啟用 ✅" else "狀態：尚未授權 ⚠️"
    }
}
